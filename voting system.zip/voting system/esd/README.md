# OnlineVotingSystemusing-BoltIoT
Online voting system built using Bolt IoT chip.
 Some of the features are not implemented but the basic structure is completed.
