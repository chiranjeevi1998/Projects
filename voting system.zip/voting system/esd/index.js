var voteBJP=0;
var voteCONGRESS=0;
