% DIP - Underwater Image Enhancement
clc;
close;
% Reading the input image
img = imread('C:\Users\CHIRANJEEVI\Desktop\ui\ui1.jpg');        %Adaptive Histogram equalization
% Original image
imshow( img );
mot_blur = fspecial('motion',15,13);
blurred = imfilter( img ,mot_blur,'conv','circular'); % adding artificial motion blurring
imshow(blurred);
%blurred = imresize(blurred , [240,320]);
imwrite(blurred,'C:\Users\CHIRANJEEVI\Desktop\ui\output\blurred.jpeg');
img = blurred;
ycbcr_ori = rgb2ycbcr(img);    %conversion to ycbcr space
figure;
imshow(ycbcr_ori);
imwrite(ycbcr_ori,'C:\Users\CHIRANJEEVI\Desktop\ui\output\ycbcr.jpeg');
y_channel = ycbcr_ori(:,:,1);
figure;
imshow(y_channel);
imwrite(y_channel,'C:\Users\CHIRANJEEVI\Desktop\ui\output\ycbcr_ychannel.jpeg');
y_channel_after_hist_eq = adapthisteq(y_channel);
figure;
imshow(y_channel_after_hist_eq);
imwrite(y_channel_after_hist_eq,'C:\Users\CHIRANJEEVI\Desktop\ui\output\ycbcr_ychannelafterHE.jpeg');
ycbcr_ori(:,:,1) = y_channel_after_hist_eq;
ycbcr_after_hist_eq = ycbcr_ori;
figure;
imshow(ycbcr_after_hist_eq);
imwrite(ycbcr_after_hist_eq,'C:\Users\CHIRANJEEVI\Desktop\ui\ycbcr_afterHE.jpeg');
rgb_after_hist_eq = ycbcr2rgb(ycbcr_after_hist_eq);
figure;
imshow(rgb_after_hist_eq);
r=rgb_after_hist_eq(:,:,1);
g=rgb_after_hist_eq(:,:,2);
b=rgb_after_hist_eq(:,:,3);
rfiltered=imgaussfilt(r,2);
bfiltered=imgaussfilt(b,2);
gfiltered=imgaussfilt(g,2);
rgb_after_hist_eq(:,:,1)=rfiltered;
rgb_after_hist_eq(:,:,2)=gfiltered;
rgb_after_hist_eq(:,:,3)=bfiltered;
rgb_after_filtering = rgb_after_hist_eq;
figure;
imshow(rgb_after_filtering);
figure;
imshow(imsharpen(rgb_after_filtering));
imwrite(rgb_after_filtering,'C:\Users\CHIRANJEEVI\Desktop\ui\output\final.jpeg');